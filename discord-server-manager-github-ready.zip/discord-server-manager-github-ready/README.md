# Discord Server Manager

Dashboard quản lý Discord Server bằng Node.js + Express + discord.js.

## Tính năng

- Discord OAuth2 Login
- Chọn Discord Server
- Dashboard tổng quan
- Quản lý thành viên
- Kick / Ban / Timeout
- Quản lý Roles
- Quản lý Channels
- Moderation
- AutoMod interface
- **Anti Link**
- Welcome
- Embed Builder
- Audit Logs
- Permission Manager
- Bot Token connection
- Bot Token được mã hóa và lưu phía server
- Responsive dark dashboard

## 1. Cài đặt

Yêu cầu Node.js 18+.

```bash
npm install
```

## 2. Tạo file `.env`

Copy:

```bash
cp .env.example .env
```

Windows:

```powershell
copy .env.example .env
```

Sau đó điền:

```env
PORT=3000
SESSION_SECRET=YOUR_LONG_RANDOM_SECRET
DISCORD_CLIENT_ID=YOUR_CLIENT_ID
DISCORD_CLIENT_SECRET=YOUR_CLIENT_SECRET
DISCORD_REDIRECT_URI=http://localhost:3000/auth/discord/callback
TOKEN_ENCRYPTION_KEY=YOUR_BASE64_32_BYTE_KEY
```

Tạo encryption key:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

## 3. Discord Developer Portal

Tạo Discord Application và Bot.

OAuth2 Redirect URL:

```text
http://localhost:3000/auth/discord/callback
```

Bot cần các intents phù hợp với chức năng dashboard, đặc biệt:

- Server Members Intent
- Message Content Intent

Bot cũng cần được invite vào server với quyền phù hợp.

## 4. Chạy

```bash
npm start
```

Mở:

```text
http://localhost:3000
```

## Anti Link

Vào:

**Anti Link → Bật Anti Link**

Sau đó nhập domain được phép, ví dụ:

```text
youtube.com
discord.com
tiktok.com
```

Bot sẽ xóa link không nằm trong danh sách cho phép.

Bot phải có quyền **Manage Messages** để xóa tin nhắn.

## Bot Token

Bot Token không được đặt trong HTML và không được commit lên GitHub.

Token được lưu phía server và mã hóa trước khi ghi vào dữ liệu.

Không commit:

```text
.env
data.json
data/*.json
```

Nếu Bot Token từng bị lộ trên GitHub hoặc nơi công khai, hãy reset token trong Discord Developer Portal.

## Deploy

Có thể deploy lên các dịch vụ Node.js/VPS hỗ trợ:

- Render
- Railway
- Fly.io
- VPS
- Docker/server Node.js

Khi deploy production:

1. Dùng HTTPS.
2. Đặt `DISCORD_REDIRECT_URI` đúng domain production.
3. Dùng `SESSION_SECRET` ngẫu nhiên mạnh.
4. Dùng `TOKEN_ENCRYPTION_KEY` cố định và lưu trong Secret/Environment Variables.
5. Không commit `.env`.
6. Không commit dữ liệu token.
7. Nên thay MemoryStore của Express Session bằng Redis/database khi chạy production.
8. Nên thêm CSRF protection và rate limiting.

## GitHub

```bash
git init
git add .
git commit -m "Initial Discord Server Manager"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

### Security

**Không paste Bot Token vào GitHub.**

Nếu token xuất hiện trong commit lịch sử, chỉ xóa file thôi là chưa đủ — hãy reset/rotate Bot Token.

