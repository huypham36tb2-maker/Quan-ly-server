require("dotenv").config();
const express=require("express"),session=require("express-session"),crypto=require("crypto"),fs=require("fs"),path=require("path");
const {Client,GatewayIntentBits,PermissionFlagsBits,ChannelType}=require("discord.js");
const app=express(),PORT=process.env.PORT||3000,DB=path.join(__dirname,"data.json");

function userStore(req){
  const uid=req.session.userId;
  data[uid]=data[uid]||{};
  return data[uid];
}
function guildConfig(req,guildId){
  const u=userStore(req);
  u.guilds=u.guilds||{};
  u.guilds[guildId]=u.guilds[guildId]||{};
  u.guilds[guildId].antiLink=u.guilds[guildId].antiLink||{enabled:false,allowedDomains:[]};
  return u.guilds[guildId];
}
function saveData(){
  fs.writeFileSync(DATA_FILE,JSON.stringify(data,null,2),{mode:0o600});
}

app.use(express.json({limit:"1mb"}));app.use(express.static(path.join(__dirname,"public")));
app.use(session({secret:process.env.SESSION_SECRET||"dev-secret",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax",secure:false,maxAge:86400000}}));
const load=()=>fs.existsSync(DB)?JSON.parse(fs.readFileSync(DB,"utf8")):{};const save=d=>fs.writeFileSync(DB,JSON.stringify(d,null,2),{mode:0o600});
function key(){const k=Buffer.from(process.env.TOKEN_ENCRYPTION_KEY||"","base64");if(k.length!==32)throw Error("TOKEN_ENCRYPTION_KEY phải giải mã thành 32 bytes");return k}
function enc(s){const iv=crypto.randomBytes(12),c=crypto.createCipheriv("aes-256-gcm",key(),iv),d=Buffer.concat([c.update(s,"utf8"),c.final()]);return{iv:iv.toString("base64"),data:d.toString("base64"),tag:c.getAuthTag().toString("base64")}}
function dec(o){const d=crypto.createDecipheriv("aes-256-gcm",key(),Buffer.from(o.iv,"base64"));d.setAuthTag(Buffer.from(o.tag,"base64"));return Buffer.concat([d.update(Buffer.from(o.data,"base64")),d.final()]).toString()}
function auth(req,res,next){if(!req.session.userId)return res.status(401).json({error:"Chưa đăng nhập Discord"});next()}
async function bot(req,fn){const r=load()[req.session.userId];if(!r?.token)throw Error("Chưa cấu hình Bot Token");const c=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent]});await c.login(dec(r.token));try{return await fn(c)}finally{c.destroy()}}
async function gdo(req,res,fn){try{res.json(await bot(req,async c=>{const g=c.guilds.cache.get(req.params.guildId);if(!g)throw Error("Bot không ở server này");return fn(c,g)}))}catch(e){res.status(400).json({error:e.message})}}
app.get("/api/token/status",requireAuth,(req,res)=>res.json({connected:!!getToken(req.session.userId)}));

app.get("/auth/discord",(req,res)=>{const q=new URLSearchParams({client_id:process.env.DISCORD_CLIENT_ID,response_type:"code",redirect_uri:process.env.DISCORD_REDIRECT_URI,scope:"identify guilds"});res.redirect("https://discord.com/oauth2/authorize?"+q)});
app.get("/auth/discord/callback",async(req,res)=>{try{const tr=await fetch("https://discord.com/api/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:new URLSearchParams({client_id:process.env.DISCORD_CLIENT_ID,client_secret:process.env.DISCORD_CLIENT_SECRET,grant_type:"authorization_code",code:req.query.code,redirect_uri:process.env.DISCORD_REDIRECT_URI})});const o=await tr.json();if(!tr.ok)throw Error("OAuth token exchange failed");const ur=await fetch("https://discord.com/api/users/@me",{headers:{Authorization:"Bearer "+o.access_token}}),u=await ur.json();req.session.userId=u.id;req.session.user={id:u.id,username:u.username,avatar:u.avatar};res.redirect("/")}catch(e){res.status(500).send("Discord login thất bại: "+e.message)}});

// Anti Link

const botClients=new Map();
async function getPersistentBotClient(req){
  const uid=req.session.userId;
  const token=getToken(uid);
  if(!token) throw new Error("Bot token chưa được kết nối.");
  let c=botClients.get(uid);
  if(c && c.isReady()) return c;
  c=new Client({intents:[
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]});
  c.on("messageCreate",async msg=>{
    if(!msg.guild || msg.author?.bot) return;
    const cfg=data[uid]?.guilds?.[msg.guild.id]?.antiLink;
    if(!cfg?.enabled) return;
    const urls=[...msg.content.matchAll(/https?:\/\/[^\s<]+|www\.[^\s<]+/gi)].map(m=>m[0]);
    if(!urls.length) return;
    const allowed=(cfg.allowedDomains||[]).map(x=>x.toLowerCase().replace(/^www\./,""));
    const blocked=urls.some(raw=>{
      try{
        const u=new URL(raw.startsWith("www.")?"https://"+raw:raw);
        const host=u.hostname.toLowerCase().replace(/^www\./,"");
        return !allowed.some(d=>host===d || host.endsWith("."+d));
      }catch{return true;}
    });
    if(!blocked) return;
    try{
      if(msg.deletable) await msg.delete();
      const w=await msg.channel.send({content:`🚫 ${msg.author}, link này không được phép trong server.`});
      setTimeout(()=>w.delete().catch(()=>{}),5000);
    }catch{}
  });
  await c.login(token);
  botClients.set(uid,c);
  return c;
}

app.get("/api/guilds/:guildId/antilink",requireAuth,(req,res)=>{
  const cfg=guildConfig(req,req.params.guildId);
  res.json(cfg.antiLink);
});
app.post("/api/guilds/:guildId/antilink",requireAuth,(req,res)=>{
  const cfg=guildConfig(req,req.params.guildId);
  const allowedDomains=Array.isArray(req.body.allowedDomains)
    ? req.body.allowedDomains.map(x=>String(x).trim().toLowerCase()
      .replace(/^https?:\/\//,"").replace(/^www\./,"").split("/")[0])
      .filter(Boolean).slice(0,100)
    : [];
  cfg.antiLink={enabled:!!req.body.enabled,allowedDomains};
  saveData();
  res.json({ok:true,antiLink:cfg.antiLink});
  startAntiLinkBot(req).catch(()=>{});
});

app.get("/api/me",(req,res)=>res.json({loggedIn:!!req.session.userId,user:req.session.user||null}));
app.post("/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.post("/api/token",auth,(req,res)=>{const t=String(req.body.token||"").trim();if(t.length<30)return res.status(400).json({error:"Bot token không hợp lệ"});const d=load();d[req.session.userId]=d[req.session.userId]||{};d[req.session.userId].token=enc(t);save(d);res.json({ok:true})});
app.delete("/api/token",auth,(req,res)=>{const d=load();if(d[req.session.userId])delete d[req.session.userId].token;save(d);res.json({ok:true})});

app.get("/api/guilds",auth,(req,res)=>gdo(req,res,(c,g)=>c.guilds.cache.map(x=>({id:x.id,name:x.name,icon:x.iconURL(),members:x.memberCount}))));
app.get("/api/guilds/:guildId/overview",auth,(req,res)=>gdo(req,res,(c,g)=>({id:g.id,name:g.name,icon:g.iconURL(),members:g.memberCount,channels:g.channels.cache.size,roles:g.roles.cache.size,owner:g.ownerId,verification:String(g.verificationLevel)})));
app.get("/api/guilds/:guildId/members",auth,(req,res)=>gdo(req,res,async(c,g)=>{await g.members.fetch();return [...g.members.cache.values()].slice(0,1000).map(m=>({id:m.id,name:m.displayName,username:m.user.username,bot:m.user.bot,roles:m.roles.cache.filter(r=>r.id!==g.id).map(r=>r.name),joined:m.joinedTimestamp}))}));
app.post("/api/guilds/:guildId/members/:userId/kick",auth,(req,res)=>gdo(req,res,async(c,g)=>{const m=await g.members.fetch(req.params.userId);await m.kick(req.body.reason||"Dashboard");return{ok:true}}));
app.post("/api/guilds/:guildId/members/:userId/ban",auth,(req,res)=>gdo(req,res,async(c,g)=>{const m=await g.members.fetch(req.params.userId);await m.ban({reason:req.body.reason||"Dashboard",deleteMessageSeconds:Math.min(Number(req.body.deleteMessageSeconds)||0,604800)});return{ok:true}}));
app.post("/api/guilds/:guildId/members/:userId/timeout",auth,(req,res)=>gdo(req,res,async(c,g)=>{const m=await g.members.fetch(req.params.userId);await m.timeout(Math.max(0,Math.min(Number(req.body.ms)||3600000,2419200000)),req.body.reason||"Dashboard");return{ok:true}}));
app.get("/api/guilds/:guildId/roles",auth,(req,res)=>gdo(req,res,(c,g)=>g.roles.cache.filter(r=>r.id!==g.id).map(r=>({id:r.id,name:r.name,color:r.hexColor,position:r.position,managed:r.managed,mentionable:r.mentionable}))));
app.post("/api/guilds/:guildId/roles",auth,(req,res)=>gdo(req,res,async(c,g)=>{const r=await g.roles.create({name:String(req.body.name||"New Role").slice(0,100),reason:"Dashboard"});return{id:r.id,name:r.name}}));
app.patch("/api/guilds/:guildId/roles/:roleId",auth,(req,res)=>gdo(req,res,async(c,g)=>{const r=g.roles.cache.get(req.params.roleId);if(!r||r.managed)throw Error("Role không thể sửa");await r.edit({name:req.body.name??r.name,mentionable:!!req.body.mentionable,reason:"Dashboard"});return{ok:true}}));
app.delete("/api/guilds/:guildId/roles/:roleId",auth,(req,res)=>gdo(req,res,async(c,g)=>{const r=g.roles.cache.get(req.params.roleId);if(!r||r.managed)throw Error("Role không thể xóa");await r.delete("Dashboard");return{ok:true}}));
app.get("/api/guilds/:guildId/channels",auth,(req,res)=>gdo(req,res,(c,g)=>g.channels.cache.map(x=>({id:x.id,name:x.name,type:x.type,parent:x.parent?.name||null}))));
app.post("/api/guilds/:guildId/channels",auth,(req,res)=>gdo(req,res,async(c,g)=>{const type=req.body.type==="voice"?ChannelType.GuildVoice:req.body.type==="category"?ChannelType.GuildCategory:ChannelType.GuildText;const x=await g.channels.create({name:String(req.body.name||"new-channel").slice(0,100),type,reason:"Dashboard"});return{id:x.id,name:x.name,type:x.type}}));
app.delete("/api/guilds/:guildId/channels/:channelId",auth,(req,res)=>gdo(req,res,async(c,g)=>{const x=g.channels.cache.get(req.params.channelId);if(!x)throw Error("Kênh không tồn tại");await x.delete("Dashboard");return{ok:true}}));
app.get("/api/guilds/:guildId/logs",auth,(req,res)=>gdo(req,res,async(c,g)=>{const logs=await g.fetchAuditLogs({limit:50});return logs.entries.map(e=>({id:e.id,action:String(e.action),user:e.executor?.username||"Unknown",target:e.target?.toString()||"",reason:e.reason||""}))}));
app.post("/api/guilds/:guildId/message",auth,(req,res)=>gdo(req,res,async(c,g)=>{const ch=g.channels.cache.get(req.body.channelId);if(!ch?.isTextBased())throw Error("Kênh không hợp lệ");await ch.send({content:String(req.body.content||"").slice(0,2000)});return{ok:true}}));
app.post("/api/guilds/:guildId/automod",auth,(req,res)=>{res.status(501).json({error:"AutoMod cần cấu hình Discord AutoMod rules; module UI đã có sẵn trong dashboard."})});
app.listen(PORT,()=>console.log(`Dashboard running at http://localhost:${PORT}`));
